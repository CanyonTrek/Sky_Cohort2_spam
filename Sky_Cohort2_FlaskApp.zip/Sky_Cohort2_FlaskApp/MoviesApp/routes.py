#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This module has our Flask routes.
"""
    Flask Routes
"""

from flask import render_template
from MoviesApp import app

# Create Flask Routes/Endpoints.
@app.route('/')
@app.route('/home')
def template_home():
    return render_template('home.html', title='STGP HOME')

@app.route('/movies')
def movies():
    movies = []
    with open(r"C:\labs\top_250.txt") as fh_in:
        for film in fh_in:
            movies.append(film)
    return render_template('movies.html', title='Movies', movies=movies)