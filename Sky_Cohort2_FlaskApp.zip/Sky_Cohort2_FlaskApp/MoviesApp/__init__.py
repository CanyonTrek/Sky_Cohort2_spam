#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

from flask import Flask

# Instantiate/Create new Flask object (web server)
app = Flask(__name__)

from MoviesApp import routes
