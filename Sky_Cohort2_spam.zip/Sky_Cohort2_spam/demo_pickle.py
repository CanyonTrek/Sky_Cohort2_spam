#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo wo to PRESERVE 1xPython Object
# to a PICKLE file using the pickle module.
"""
    DocString:
"""
import pickle
import pprint
import gzip # Other modules tarfile, shutil, bz2..

movies = { 'neil': ['man of steel', 'scary movie', 'police academy'],
           'steven': ['avengers end game', 'the usual suspects', 'dark knight'],
           'matthew': ['jaws' ,'spiderman', 'scarface'],
           'sidhra': ['avengers', 'matilda', 'silence of lambs']
}

# Open File Handle to a Pickle file for WRITING in BYTES mode.
# with open(r"C:\labs\projects\Sky_Cohort2_spam\movies.p", mode="wb") as fh_out:
with gzip.open(r"C:\labs\projects\Sky_Cohort2_spam\movies.pgz", mode="wb") as fh_out:
    # pickle.dump(movies, fh_out, protocol=5) # Protocol (0=ascii, 1-5=binary)
    # pickle.dump(movies, fh_out, pickle.DEFAULT_PROTOCOL) # DEFAULT=4
    pickle.dump(movies, fh_out, pickle.HIGHEST_PROTOCOL)  # HIGHEST=5

# Open File Handle to a Pickle file for READING in BYTES mode.
# with open(r"C:\labs\projects\Sky_Cohort2_spam\movies.p", mode="rb") as fh_in:
with gzip.open(r"C:\labs\projects\Sky_Cohort2_spam\movies.pgz", mode="rb") as fh_in:
    films = pickle.load(fh_in)

pprint.pprint(movies)
print("-" * 60)
pprint.pprint(films)


