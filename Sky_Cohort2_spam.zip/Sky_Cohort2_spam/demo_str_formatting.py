#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo different ways of formatting strings.
"""
    DocString:
"""

# A dict of planets and their distance to sun in Gigametres.
planets = {'Mercury': 57.91,
           'Venus': 108.2,
           'Earth': 149.597870,
           'Mars': 227.94
}

# Iterate through dict keys and display Formatted planet info..
# Using str concatenation + esape chars. UGLY!
for planet in planets.keys():
    print("\t\t" + planet + ": \t" + str(planets[planet]) + "Gm\t" + str(hex(0xff)))

print("-" * 60) # Example of str repetition.
# Using str concatenation + str justification methods. Ok!
for planet in planets.keys():
    print(planet.rjust(12) + ": " + str(planets[planet]).center(12, '.')
          + "Gm " + str(hex(0xff)).rjust(6))

print("-" * 60) # Example of str repetition.
# Using str .format() method. Py3 onwards. Good!
for planet in planets.keys():
    print("{0:>12s}: {1:.^12.3f}Gm {2:>#6x}".format(planet, planets[planet], 0xff))

print("-" * 60) # Example of str repetition.
# Using f-strings Py3.5 onwards. BEST!
for planet in planets.keys():
    print(f"{planet:>12s}: {planets[planet]:.^12.3f}Gm {0xff:>#6x}")

print("-" * 60) # Example of str repetition.
# Using PYTHON 2 string formatting. OLDIE and DATED!
for planet in planets.keys():
    print("%12s: %12.3fGm %#6x" % (planet, planets[planet], 0xff))