#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match text data using string
# testing and pattern matching using the Regular Expressions and the re.py
# module.
"""
    DocString:
"""
import re

# Open file handle for READING in TEXT mode.
fh_in = open(r"c:\labs\words", mode="rt")

reobj = re.compile(r"^([A-Z]).*\1$") # Precompiles PATTERN ONCE!

# Iterate through file handle one line at a time.
for line in fh_in:
    # m = re.search(r"^([A-Z]).*\1$", line) # Match lines start/end with same capital!
    m = reobj.search(line)  # Match lines start/end with same capital!
    if m:
        print(line, end="")

fh_in.close() # Close file handle.
