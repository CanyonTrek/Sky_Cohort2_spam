#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match text data using string
# testing and pattern matching using the Regular Expressions and the re.py
# module.
"""
    DocString:
"""
import re

# Open file handle for READING in TEXT mode.
fh_in = open(r"c:\labs\words", mode="rt")

# Iterate through file handle one line at a time.
for line in fh_in:
    # Example of str testing.
    # if line.startswith("Y") and line.rstrip("\n").endswith("n") and "town" in line:
    # m = re.search(r"^Y", line) # Match lines starting with 'Y'.
    # m = re.search(r"^the", line) # Match lines starting with 'the'.
    # m = re.search(r"ing$", line) # Match lines ending with 'ing'.
    # m = re.search(r"^ring$", line) # Match lines with only 'ring'.
    # m = re.search(r"^.ing$", line)  # Match lines with only 'ring'.
    # m = re.search(r"^...................$", line)  # Match lines with exactly 19 chars
    # m = re.search(r"^.{19}$", line) # Match lines with exactly 19 chars.
    # m = re.search(r"^[A-Z]", line)  # Match lines starting with a capital.
    # m = re.search(r"[0-9]", line)  # Match lines with a digit.
    # m = re.search(r"[aeiou][aeiou][aeiou]", line)  # Match lines with 3 consecutive vowels.
    # m = re.search(r"[aeiou]{5,}", line)  # Match lines with at least 5 consecutive vowels.
    # m = re.search(r"\.", line) # Match lines with a '.'!
    # m = re.search(r"^[A-Z].*[A-Z]$", line) # Match lines start/end with a capital.
    # m = re.search(r"^[A-Z].{5}[A-Z]$", line) # Match lines start/end with a capital.
    # m = re.match(r"^[A-Z].{5}[A-Z]$", line)  # match() always matches lines starting with pattern.
    # m = re.fullmatch(r"^[A-Z].{5}[A-Z]\n$", line)  # Match Entire line including hidden chars.
    # m = re.search(r"^(.)(.).\2\1$", line) # Match lines with 5 char palindromes.
    # m = re.search(r"^([A-Z]).*\1$", line)  # Match lines start/end with same capital!
    m = re.search(r"^([A-Z]).*\1$", line, flags=re.IGNORECASE) # Match lines start/end with same capital!
    if m:
        print(line, end="")

fh_in.close() # Close file handle.