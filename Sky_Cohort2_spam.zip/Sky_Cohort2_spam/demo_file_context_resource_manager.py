#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo a SAFER way to manage resources like
# file handles so they ONLY exist for a BLOCK (Context Resource Manager).
"""
    DocString:
"""
import sys
# Create a multi-dimensional dict of lists.
movies = { 'neil': ['man of steel', 'scary movie', 'police academy'],
           'steven': ['avengers end game', 'the usual suspects', 'dark knight'],
           'matthew': ['jaws' ,'spiderman', 'scarface'],
           'sidhra': ['avengers', 'matilda', 'silence of lambs']
}

# Open file handle for WRITING in TEXT mode.
with open(r"C:\labs\projects\Sky_Cohort2_spam\movies.txt", mode="wt") as fh_out:
    for name in movies.keys():
        print(f"{name}: {movies[name]}", end="\n", file=sys.stdout)
        print(f"{name}: {movies[name]}", end="\n", file=fh_out)
        # fh_out.write(f"{name}: {movies[name]}\n")
    # End of block, fh_out automatically flushed and closed.

print("-" * 60)

# Open File Handle for READING in TEXT mode.
with open(r"C:\labs\projects\Sky_Cohort2_spam\movies.txt", mode="rt") as fh_in:
    for line in fh_in:
        print(line, end="", file=sys.stdout)
