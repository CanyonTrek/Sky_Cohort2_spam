#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to ITERATE through a
# sequence (str/tuple/list/dict/set) using an ITERATOR for loop.
"""
    DocString:
"""
#             0                1                       2
bands = ['linkin park', 'florence and the machine', '5sos',
         'queen', 'abba', 'nirvana', 'jackson 5']

# ITERATE through the list objects USING an ITERATOR for loop.
for name in bands:
    print(name.upper(), end="\n")
print("Fav bands =", bands)

# ITERATE through the list objects USING an ITERATOR for loop
# and modify the objects using a loop index.
idx = 0
for name in bands:
    print(name.title(), end="\n")
    bands[idx] = name.title()
    idx += 1
print("Fav bands =", bands)

# ITERATE through the list objects USING an ITERATOR for loop
# and modify the objects using built-in enumerate() function.
for (idx, name) in enumerate(bands, start=0):
    print(name.swapcase(), end="\n")
    bands[idx] = name.swapcase()
print("Fav bands =", bands)