#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open, close, and read, write
# and append to a text file.
"""
    DocString:
"""
# Create a multi-dimensional dict of lists.
movies = { 'neil': ['man of steel', 'scary movie', 'police academy'],
           'steven': ['avengers end game', 'the usual suspects', 'dark knight'],
           'matthew': ['jaws' ,'spiderman', 'scarface'],
           'sidhra': ['avengers', 'matilda', 'silence of lambs']
}

# Open file handle for WRITING in TEXT mode.
fh_out = open(r"C:\labs\projects\Sky_Cohort2_spam\movies.txt", mode="wt")

# ITERATE through dict and write key+object to file handle using
# an ITERATOR for loop.
for name in movies.keys():
    print(f"{name}: {movies[name]}", end="\n")
    fh_out.write(f"{name}: {movies[name]}\n")

# fh_out.flush() # Flush buffers.
fh_out.close() # Flush buffers and close file handle.

print("-" * 60)

# Open File Handle for READING in TEXT mode.
fh_in = open(r"C:\labs\projects\Sky_Cohort2_spam\movies.txt", mode="rt")

# text = fh_in.read() # Read ENTIRE file into str object. Be careful if LARGE file!
# text = fh_in.read(30) # Read NEXT 30 chars from file into str.
# text = fh_in.readline() # Read NEXT LINE from file into str.
# lines = fh_in.readlines() # Read ENTIRE LINES from file into LIST. Be Careful Large files!
# print(f"1st line = {lines[0]}")
# print(f"Last line = {lines[-1]}")

# ITERATE through the file handle, one line at a time using
# an ITERATOR for loop plus filehandle (Iterator object, next()/iter())
# for line in open(r"C:\labs\projects\Sky_Cohort2_spam\movies.txt", mode="rt"):
for line in fh_in:
    print(line, end="")

fh_in.close() # Close File Handle.