#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will display the entire Unicode char set.
"""
    DocString:
"""

# ITERATE through Unicode char positions (0-65535) using an
# ITERATOR for loop and the built-in range() function.
for pos in range(0, 65536):
    try:
        if pos % 16 == 0:
            print()
        print(chr(pos), end=" ")
    except UnicodeEncodeError:
        print(" ")
