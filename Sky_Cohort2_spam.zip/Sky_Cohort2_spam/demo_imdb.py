#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

fh_in = open(r"C:\labs\top_250.txt", mode="rt")

for rank, movie in enumerate(fh_in, start=1):
    print(f"{rank}. {movie}", end="")