#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to Split and rejoin strings
# using the .split() and .join() methods.
"""
    DocString:
"""

# Sample line from /etc/passwd on Linux for the root user login.
# I want to make changes to string! But str are immutable/read only.
line = "root:x:0:0:The Super User:/root:/bin/ksh"

fields = line.split(":") # Return a list (Mutable).
fields[4] = "The Administrator"
fields[6] = "/bin/bash"
print(fields)

line = ":".join(fields) # Returns a str.
print("Modified string=", line)