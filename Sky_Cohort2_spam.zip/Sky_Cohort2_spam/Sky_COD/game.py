#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This is an ultra realistice game with Tanks!
"""
    GOT - Game of Tanks!
"""

import tank

# Instantiate/Create 3 new Tank objects!
uma_tank = tank.Tank('German', 'Tiger')
riya_tank = tank.Tank('American', 'Sherman')
nish_tank = tank.Tank('British', 'Churchill')

# And the game begins..
uma_tank.accel(64)
riya_tank.accel(29)

nish_tank.rotate_left(285)
nish_tank.accel(32)
nish_tank.shoot()

# ..and success"
uma_tank.take_damage(59)
riya_tank.take_damage(37)

# And now for some visuals! Well a print statement or two!
# print(f"Health of Uma's tank is {uma_tank._health}") # POOR CODE!

# Example of Operator Overloading.
print(f"Health of Uma's and Riya's tank = {uma_tank + riya_tank}")

# Example of using a getter and setter methods.
# uma_tank._health = 99 # POOR CODE!
# print(f"Uma's new health is {uma_tank._health}") # POOR CODE!

# Example of using a getter and setter methods.
uma_tank.set_health(100) # SETTER method!
print(f"Uma's new health is {uma_tank.get_health()}") # GETTER method!

# Example of using a variable with a special property.
uma_tank.tank_health = 101
print(f"Uma's new health is {uma_tank.tank_health}") #

# Example of Duck Typing - our Tanks can now Quack like a str!
print(f"Status of Uma's Tank: {uma_tank}")