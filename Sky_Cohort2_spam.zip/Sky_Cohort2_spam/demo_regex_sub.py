#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match and SUBSTITUTE text
# using Regex patterns and the re.sub() function.
"""
    DocString:
"""
import re

# Sample from /etc/passwd on Linux of the root user login.
line = "root:x:0:0:The Super User:/root:/bin/ksh"

line = re.sub(r"[Ss]uper [Uu]ser", r"Administrator", line) # Returns Modified str.
line = re.sub(r"ksh$", r"bash", line) # Returns Modified str.

print(f"Modified string = {line}")