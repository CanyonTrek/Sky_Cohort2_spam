#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to repeat a block of commands
# specific repetitions by using a COUNTER loop.
"""
    DocString:
"""

count = 0 # 1.Initialise loop counter.
while count < 10: # 2.Test loop counter.
    print(count)
    count += 1 # 3.Increment loop counter.

# Alternatively, in Python we can use the for loop
# plus the built-in range(start, stop, step) function.
for num in range(0, 10, 1):
    print(num)

# Built-in range(start, stop, step=1) function.
for num in range(0, 10):
    print(num)

# Built-in range(start=0, stop, step=1) function.
for num in range(10):
    print(num)