#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow and shrink sets
# sets = unordered collection of unique objects.
"""
    DocString:
"""
marvel_fans = {'david', 'neil', 'sidhra', 'donald', 'faeiq', 'nish'}
dc_fans = set() # Create an empty set!

dc_fans.add('olivia')
dc_fans.add('donald')
dc_fans.add('uma')
# comic_fans = dc_fans.copy() # Create copy of set.
# comic_fans.clear() # Empty set.
# dc_fans.pop() # Randomly remove an object.

print(f"Fans of Marvel = {marvel_fans}")
print(f"Fans of DC = {dc_fans}")
print("-" * 60)

# Combine sets using SET METHODS (Remember VENN diagrams)
print(f"Fans of either Marvel AND DC = {marvel_fans.union(dc_fans)}")
print(f"Fans of both Marvel AND DC = {marvel_fans.intersection(dc_fans)}")
print(f"Fans of both Marvel ONLY = {marvel_fans.difference(dc_fans)}")
print(f"Fans of either Marvel OR DC ONLY = {marvel_fans.symmetric_difference(dc_fans)}")
print("-" * 60)
# Combine sets using SET OPERATORS (Remember VENN diagrams)
print(f"Fans of either Marvel AND DC = {marvel_fans | dc_fans}")
print(f"Fans of both Marvel AND DC = {marvel_fans & dc_fans}")
print(f"Fans of both Marvel ONLY = {marvel_fans - dc_fans}")
print(f"Fans of either Marvel OR DC ONLY = {marvel_fans ^ dc_fans}")
