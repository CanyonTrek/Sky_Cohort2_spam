#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow, and shrink
# dict (Mutable collection of object with Unique Keys). But 3.6 dict
# are ordered in INSERTION ORDER.
"""
    DocString:
"""
import pprint

# Create a dict of lists (multi-dimensional) of movies.
movies = { 'neil': ['man of steel', 'scary movie', 'police academy'],
           'steven': ['avengers end game', 'the usual suspects', 'dark knight'],
           'matthew': ['jaws' ,'spiderman', 'scarface']
}

# Grow dict by adding key+object.
movies['donald'] = ['braveheart', 'brave', 'babe']
movies['sidhra'] = ['avengers', 'matilda', 'silence of lambs']

# Dict methods..
# films = movies.copy() # Copy dict.
# films.clear() # Empty dict.

print(f"Steven's favourite films are {movies['steven']}")
print(f"Steven likes {movies.get('steven')}")
print(f"Stevens ultimate movies is {movies['steven'][0]}")

movies.pop('donald') # Remove key+object.
movies.popitem() # Remove last key_object INSERTED!

# ITERATING through dict keys, or values, or both using
# an ITERATOR for loop plus the .keys(), ,values() and .items() methods.
for name in movies.keys():
    print(f"{name} likes {movies[name]}")

for films in movies.values():
    print(f"Good films: {films}")

# Iterate through keys+objects.
for name, films in movies.items():
    print(f"{name} loves {films}")