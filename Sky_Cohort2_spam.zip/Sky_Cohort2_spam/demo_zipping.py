#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to ITERATE through separate
# but INDEX-RELATED sequences (str/tuple/list/dict/sets)
"""
    DocString:
"""
import sys
# Create 4 separate but index-related lists.
grads = ['steven', 'neil', 'matthew']
fav_bands = ['jackson 5', 'linkin park', 'bee gees']
fav_heroes = ['dad', 'wife', 'bill gates']
fav_locs = ['yorkshire', 'spain', 'sydney']

# ITERATE through SEPARATE but INDEX-RELATED lists
# to get all the Index 0s, then Index 1s etc.
for (g, fb, fh, fl)  in zip(grads, fav_bands, fav_heroes, fav_locs):
    print(g + " likes to listen " + fb + " with " + fh + " in " + fl)

# sys.exit("goodbye") # Explicit EXIT, send "message" to STDERR (red) and error code=1.
sys.exit(0) # EXplicit EXIT program with error code (0=success, 1-255=error code)

