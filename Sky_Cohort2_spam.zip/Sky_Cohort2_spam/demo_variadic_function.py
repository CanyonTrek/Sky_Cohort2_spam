#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to define a VARIADIC function
# which is a function that accepts variable num of parameters.
"""
    This is a Search tool for matching Regex patterns in one or more
    files.
"""
import re

# Example of a Variadic user function with parameter
# passing and defaults and annotations. Accepts variable num
# of parameters. Unpacks remaining parameters into a TUPLE!
def search_pattern(pattern:str="^.{19}$", *files)->int:
    """ Search for Regex pattern, print matched strings and
        return num of lines matched
        search_pattern(Regex, file/s)
    """
    lines = 0
    for file in files:
        with open(file, mode="rt") as fh_in:
            for line in fh_in:
                m = re.search(pattern, line) # Match pattern against input string.
                if m:
                    lines += 1
                    print(f"Matched {m.group()} on {line.rstrip()} at {m.start()}-{m.end()}")

    return lines

num_lines = search_pattern(r"[aeiou]{5,}", r"c:\labs\words", r"c:\labs\words2", r"c:\labs\words2")
print(f"Number of lines matched = {num_lines}")

print(f"Annotations for search_pattern = {search_pattern.__annotations__}")
