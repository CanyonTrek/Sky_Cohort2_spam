#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create a resuable user function
# for searching for a Regex Pattern in a file.
"""
    DocString:
"""
import re

# Example of a useful user function with parameter
# passing and defaults and annotations.
def search_pattern(pattern:str="^.{19}$", file:str=r"c:\labs\words")->int:
    lines = 0
    with open(file, mode="rt") as fh_in:
        for line in fh_in:
            m = re.search(pattern, line) # Match lines start/end with same capital!
            if m:
                lines += 1
                print(f"Matched {m.group()} on {line.rstrip()} at {m.start()}-{m.end()}")

    return lines

search_pattern()
num_lines = search_pattern(r"[aeiou]{4}")
print(f"Number of lines matched = {num_lines}")
