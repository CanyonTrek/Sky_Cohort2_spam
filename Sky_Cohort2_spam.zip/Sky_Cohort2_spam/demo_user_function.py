#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to DEFINE, NAME and CALL
# user functions and optionally pass parameters in and data back out.
"""
    DocString:
"""

# Example of a user function with parameter passing and
# default values. With Annotations (Embedded comment specifying
# expected data types for parameters - BUT it's not enforced!
def say_hello(greeting:str="konichiwa", recipient:str="tomodachi")->None:
    message = f"{greeting} {recipient}"
    print(message)
    return None

say_hello("Bonjour", "mes amis") # Positional parameter possing.
say_hello(greeting="hiya", recipient="pal") # Named parameter passing.
say_hello(recipient="dias amigos", greeting="beunos") # Named parameter passing in different order.
say_hello("hallo", recipient="mein freunde") # Mixed parameter passing (pos->named)
say_hello("konichiwa")
say_hello()
