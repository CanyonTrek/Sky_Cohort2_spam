#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will simulate an ATM machine with PIN entry.
"""
    DocString:
"""

master_pin = "0123"
pin = None
attempts = 0

# Repeat whilst PIN is not correct. Max 3 attempts allowed.
while pin != master_pin and attempts < 3:
    pin = input("Enter PIN: ")
    if pin == master_pin:
        print("Valid PIN")
        break
    else:
        print("Invalid PIN")
        attempts += 1
else:
    # Only execute ONCE when Loop naturally becomes False.
    print("Too many attempts.")
    print("Your card has been retained. Have a nice day")


print("Done")